#include <stdio.h>
#include <stdbool.h>

int nbChemins;
int n;
int arrGrid[100][100];

bool bouger(int a,int b){
    //if(a<n-1 && b<n-1){
        bool res;
        if(a==0 && b==0 && ((arrGrid[a][b+1]==0 && arrGrid[a+1][b]==-1 ) ||(arrGrid[a][b+1]==-1 && arrGrid[a+1][b]==0))){
            nbChemins++;
            printf("1er cas %d\r\n",nbChemins);

        }
        if(b+1<=n-1 && arrGrid[a][b+1]==0 
        && a+1<=n-1 && arrGrid[a+1][b]==0 &&bouger(a,b+1) &&bouger(a+1,b) ){
            nbChemins++;
            if(a==0 && b==0){
                nbChemins++;
            }
        }
        
        if(b+1<=n-1 && arrGrid[a][b+1]==0 ){
            res=bouger(a,b+1);
            printf("droite");
        }
        if(a+1<=n-1 && arrGrid[a+1][b]==0 ){
            res=res || bouger(a+1,b);
            printf("gauche");
        }
        if(a==n-1 && b==n-1){
            return true;
            //nbChemins++;
        }
        
    //}
}

int main(){
    n;
	scanf("%d", &n);
	arrGrid[100][100];
	char temp;

    int nPosI,nPosJ ;
	for ( nPosI = 0; nPosI < n; nPosI++) {
		for ( nPosJ = 0; nPosJ < n; nPosJ++) {
			scanf("%d%c", &arrGrid[nPosI][nPosJ], &temp);
		}
	}
    bool res = bouger(0,0);
    if(res==false){
        nbChemins=0;
    }
    printf("%d\r\n",nbChemins);
}